# dcrd v{TODO: X.Y.Z} Draft Release Notes

This is a patch release of dcrd which includes the following changes:

- {TODO: List resolved issues}

## Changelog

This patch release consists of {TODO: #} commits from {TODO: #} contributors
which total to {TODO: #} files changed, {TODO: #} additional lines of code, and
{TODO: #} deleted lines of code.

All commits since the last release may be viewed on GitHub
[here](https://github.com/decred/dcrd/compare/release-v{TODO:X.Y.Z-1}...release-v{TODO: X.Y.Z}).

### {TODO: Categorized commits -- Follow categories from major release template}

{TODO: Add bullet points for each commit w/ PR link}

### Code Contributors (alphabetical order):

- {TODO: Add all code contributors}
- {TODO: Code contributor 2}
- {TODO: Code contributor 3}
