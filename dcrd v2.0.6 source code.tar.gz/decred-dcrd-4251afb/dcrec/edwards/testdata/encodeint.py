import sys
from ed25519 import *

encodeinthex(int(sys.argv[1]))
