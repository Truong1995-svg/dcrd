import sys
from ed25519 import *

decodepointhex(sys.argv[1])

